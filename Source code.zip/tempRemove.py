import os
import shutil
from pathlib import Path

def delete_temp_contents(folder):
    if not os.path.exists(folder):
        return
    for item in os.listdir(folder):
        item_path = os.path.join(folder, item)
        try:
            if os.path.isfile(item_path) or os.path.islink(item_path):
                os.unlink(item_path)
            elif os.path.isdir(item_path):
                shutil.rmtree(item_path, ignore_errors=True)
            print(f"✅ Удалено: {item_path}")
        except Exception as e:
            print(f"❌ Не удалось удалить {item_path}: {e}")

def ask_confirm(path):
    answer = input(f"\nОчистить папку '{path}'? [y/N]: ").strip().lower()
    return answer == 'y'

# Сбор всех известных Temp-папок
temp_paths = set()

# TEMP и TMP из окружения
for var in ['TEMP', 'TMP']:
    temp = os.getenv(var)
    if temp:
        temp_paths.add(temp)

# Windows Temp
temp_paths.add(os.path.expandvars(r"%SystemRoot%\Temp"))

# Temp в каждом профиле пользователя
users_path = Path("C:/Users")
if users_path.exists():
    for user_folder in users_path.iterdir():
        temp_dir = user_folder / "AppData" / "Local" / "Temp"
        if temp_dir.exists():
            temp_paths.add(str(temp_dir))

# Подтверждение и удаление
for path in sorted(temp_paths):
    if ask_confirm(path):
        print(f"🧹 Очистка: {path}")
        delete_temp_contents(path)
    else:
        print(f"⏩ Пропущено: {path}")
